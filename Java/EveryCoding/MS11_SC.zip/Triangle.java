package MS11;

public class Triangle {

	private double width;
	private double height;
	
	// TO-DO
	
}
