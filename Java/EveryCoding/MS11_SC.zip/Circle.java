package MS11;

public class Circle {

	private double radius;
	final static double PI = 3.1415926535;
	
	// TO-DO
	
	
}
