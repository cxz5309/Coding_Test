package MS11;

public class Trapezoid {
	
	private double top;
	private double bottom;
	private double height;	
	
	// TO-DO
	
}
