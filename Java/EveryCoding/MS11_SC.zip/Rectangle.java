package MS11;

public class Rectangle {

	private double width;
	private double height;
	
	// TO-DO
	
	
}
